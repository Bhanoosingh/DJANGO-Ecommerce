from django.shortcuts import render

# Create your views here.

def index(request):
    products=[1,2,3,4,5,6,7,8,9]
    return render(request,'shop/index.html',{'products':products})
